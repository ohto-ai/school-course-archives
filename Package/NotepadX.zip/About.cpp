#include "About.h"

About::About(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

About::~About()
{
}
