#include "FindDialog.h"

FindDialog::FindDialog(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

FindDialog::~FindDialog()
{
}
