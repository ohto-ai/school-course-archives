﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 ThatboyEncryptFileEncoder.rc 使用
//
#define IDDTEF_THATBOYENCRYPTFILEENCODER_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDCTEF_FILEPATH                 1000
#define IDCTEF_BROWER                   1001
#define IDCTEF_ENCRYPT                  1002
#define IDCTEF_DECRYPT                  1003
#define IDCTEF_PASSWORD                 1004
#define IDCTEF_NEEDPASSWORD             1005
#define IDCTEF_NEEDDEVICEBIND           1006
#define IDCTEF_DEVICESERIAL             1007
#define IDCTEF_INFOBOX                  1008
#define IDCTEF_CHUNKDATASIZE            1009
#define IDCTEF_PROGRESSBAR              1010
#define IDCTEF_CRC32TYPE                1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
