#include "OptionDialog.h"

OptionDialog::OptionDialog(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

OptionDialog::~OptionDialog()
{
}
